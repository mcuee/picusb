
   List of files Cypress PDC-9086-A.zip 
   
    1.  121-08600-A.pdf - PDF File's of Assembly Drawings Top & Bottom.
    2.  art_param.txt - Text file general parameters for gerber's.      
    3.  BOTTOM,art - Gerber file of Solder Side Layer 4.
    4.  FAB.art - Gerber file of Drill Drawing
    5.  GND.art - Gerber file of Ground Plane Layer 2.
    6.  nc_parm.txt - Text file general parameters for drill data.
    7.  ncdrill1.tap  - Drill List.
    8.  nctape.log -  ncdrill parameters.
    9.  PDC-9086-A.pdf - PDF file of Drill Drawings & Layers 1-4.  
   10.  PDC-9086-A-INSERT - Insert file for SMD components.
   11.  psm.art - Gerber file of Top Side Soldermask.              
   12.  psp.art - Gerber file of Top Side Pastemask.
   13.  pss.art - Gerber file of Silkscreen Top Side.
   14.  README.txt - List of Files.   
   15.  ssm.art - Gerber file of Bottom Side Soldermask.
   16.  ssp.art - Gerber file of Bottom Side Pastemask. 
   17.  sss.art - Gerber file of Bottom Side Silkscreen.         
   18.  TOP.art - Gerber file of Top Side Layer 1. 
   19.  VCC.art - Gerber File of Power Plane Layer 3.
   
   
                
   
   
   If you have any questions please call. Thank -You

       CYPRESS SEMICONDUCTOR
         Michael P Kingsley
        15050 Avenue of Science
        San Diego, CA 92128
        Phone: (858) 613-7931
        Fax: (858) 676-3911
        E-mail: zmk@cypress.com